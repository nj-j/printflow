import React, { useState } from 'react';
import {
  Printer,
  Play,
  Pause,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Zap,
  Gauge,
  Clock,
  Layers,
  FileCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PrintingTerminal = () => {
  const {
    jobOrders,
    workstationLogs,
    advanceJobStage,
    activeUser,
    setSelectedJobForModal,
    setActiveTab,
    activeSubTab,
    setActiveSubTab
  } = useApp();

  const currentSubTab = activeSubTab || 'live_terminal';

  const pressJobs = jobOrders.filter(j => j.current_stage === 'PressRun' || j.current_stage === 'PlateMaking');
  const activeJob = pressJobs[0] || jobOrders[0];

  const [currentImpressions, setCurrentImpressions] = useState(2450);
  const [wasteSheets, setWasteSheets] = useState(45);
  const [operatorNotes, setOperatorNotes] = useState('CMYK density 1.45 calibrated on sheet pull. Running at 11,000 IPH.');
  const [densityChecked, setDensityChecked] = useState(true);
  const [registrationChecked, setRegistrationChecked] = useState(true);
  const [blanketCleanChecked, setBlanketCleanChecked] = useState(true);
  const [isRunning, setIsRunning] = useState(true);

  const targetImpressions = activeJob?.print_quantity || 3000;
  const progressPercent = Math.min(100, Math.round((currentImpressions / targetImpressions) * 100));

  const handleIncrementImpressions = (amount) => {
    setCurrentImpressions(prev => Math.min(targetImpressions, prev + amount));
  };

  const handleCompletePressRun = () => {
    if (!activeJob) return;
    advanceJobStage(
      activeJob.id,
      'FinishingQC',
      `Press run completed (${currentImpressions} impressions, ${wasteSheets} scrap sheets logged by ${activeUser.full_name}).`
    );
    setActiveTab('finishing');
  };

  const subTabs = [
    {
      id: 'live_terminal',
      label: 'Live Terminal',
      icon: Printer,
      badge: 'Live',
      badgeColor: 'bg-emerald-100 text-emerald-800'
    },
    {
      id: 'counters',
      label: 'Impression Counter',
      icon: Gauge,
      badge: `${currentImpressions.toLocaleString()} IPH`,
      badgeColor: 'bg-blue-100 text-blue-700'
    },
    {
      id: 'calibration',
      label: 'Setup & Calibration',
      icon: CheckCircle2,
      badge: densityChecked && registrationChecked ? 'Calibrated' : 'Check Required',
      badgeColor: 'bg-amber-100 text-amber-800'
    }
  ];

  return (
    <div className="space-y-3">
      {/* Consolidated Module Header with Sub-Tabs */}
      <div className="bg-white border-b border-slate-200 px-6 py-3 shadow-2xs select-none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 max-w-[1600px] mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#001523] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              05
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">Press Terminal (MES)</h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                  Consolidated Suite
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Dedicated touch MES terminal for machine operators (Ryobi 524HX, Komori Lithrone, Konica Minolta)
              </p>
            </div>
          </div>

          {/* Sub-Tab Navigation Bar */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 gap-1 text-xs">
            {subTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = currentSubTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#001523] font-bold shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-emerald-600' : 'text-slate-500'} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-bold ${tab.badgeColor}`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="stage-page-container">
        {/* Machine Selector Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-white p-3 rounded-xl border border-slate-200 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-slate-700 font-mono uppercase px-2">Active Line:</span>
            <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg font-bold text-xs flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Ryobi 524HX (4-Color Offset Press)
            </span>
            <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium cursor-pointer hover:bg-slate-200">
              Komori Lithrone 429
            </span>
            <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium cursor-pointer hover:bg-slate-200">
              Konica Minolta AccurioPress
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="badge badge-success flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> Live Machine Sync
            </span>
          </div>
        </div>

      {activeJob ? (
        <div className="press-terminal-layout">
          {/* Active Job Terminal Cockpit */}
          <div className="card flex-1">
            <div className="card-header bg-slate-900 text-white p-4 rounded-t-lg">
              <div>
                <div className="flex items-center gap-2">
                  <span className="ticket-tag font-bold">{activeJob.job_ticket_number}</span>
                  {activeJob.is_rush_order && (
                    <span className="badge badge-danger text-xxs font-bold animate-pulse">
                      [URGENT PRIORITY RUN]
                    </span>
                  )}
                </div>
                <h3 className="text-white text-lg font-bold mt-1">{activeJob.job_title}</h3>
                <p className="text-slate-300 text-xs mt-0.5">
                  Customer: <strong>{activeJob.customer_name}</strong> | Assigned Press: <strong>{activeJob.assigned_press_machine}</strong>
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400 block">Operator on Shift:</span>
                <span className="text-sm font-semibold text-white">{activeUser.full_name}</span>
              </div>
            </div>

            <div className="p-4">
              {/* Big Gauges & Impression Counter */}
              <div className="impressions-counter-box">
                <div className="counter-metric">
                  <span className="metric-label">Target Impressions</span>
                  <div className="metric-val text-primary">{targetImpressions.toLocaleString()}</div>
                </div>

                <div className="counter-metric counter-metric-active">
                  <span className="metric-label">Good Printed Impressions</span>
                  <div className="metric-val text-success">{currentImpressions.toLocaleString()}</div>
                </div>

                <div className="counter-metric">
                  <span className="metric-label">Make-Ready Scrap Sheets</span>
                  <div className="metric-val text-danger">{wasteSheets} Sheets</div>
                </div>

                <div className="counter-metric">
                  <span className="metric-label">Run Completion</span>
                  <div className="metric-val text-slate-800">{progressPercent}%</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="progress-bar-bg h-4 mt-3">
                <div
                  className="progress-bar-fill bg-success h-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>

              {/* Press Speed & Impression Step Buttons */}
              <div className="terminal-actions-row mt-4">
                <div className="flex gap-2">
                  <button
                    className="btn btn-secondary flex items-center gap-1"
                    onClick={() => handleIncrementImpressions(100)}
                  >
                    +100 Sheets
                  </button>
                  <button
                    className="btn btn-secondary flex items-center gap-1"
                    onClick={() => handleIncrementImpressions(500)}
                  >
                    +500 Sheets
                  </button>
                  <button
                    className="btn btn-primary flex items-center gap-1"
                    onClick={() => handleIncrementImpressions(1000)}
                  >
                    +1,000 Sheets
                  </button>
                </div>

                <div className="flex gap-2 ml-auto">
                  <button
                    className="btn btn-warning flex items-center gap-1"
                    onClick={() => setWasteSheets(prev => prev + 10)}
                  >
                    +10 Scrap Sheets
                  </button>
                  <button
                    className={`btn ${isRunning ? 'btn-danger' : 'btn-success'} flex items-center gap-1`}
                    onClick={() => setIsRunning(!isRunning)}
                  >
                    {isRunning ? <Pause size={16} /> : <Play size={16} />}
                    {isRunning ? 'Pause Press' : 'Resume Press'}
                  </button>
                </div>
              </div>

              {/* In-Process Quality Checks */}
              <div className="inprocess-qc-card mt-4">
                <h4 className="font-bold text-xs flex items-center gap-1 mb-2">
                  <FileCheck size={16} className="text-success" /> Mandatory In-Process Press Quality Checks
                </h4>
                <div className="qc-checkbox-grid">
                  <label className="qc-check-item">
                    <input
                      type="checkbox"
                      checked={densityChecked}
                      onChange={(e) => setDensityChecked(e.target.checked)}
                    />
                    <span>CMYK Ink Density 1.45 Calibrated</span>
                  </label>
                  <label className="qc-check-item">
                    <input
                      type="checkbox"
                      checked={registrationChecked}
                      onChange={(e) => setRegistrationChecked(e.target.checked)}
                    />
                    <span>Cross-hair Registration & Bleed Aligned</span>
                  </label>
                  <label className="qc-check-item">
                    <input
                      type="checkbox"
                      checked={blanketCleanChecked}
                      onChange={(e) => setBlanketCleanChecked(e.target.checked)}
                    />
                    <span>Blanket Cleaned (Zero Hickey Marks)</span>
                  </label>
                </div>
              </div>

              {/* Shift Notes & Handover */}
              <div className="mt-3">
                <label className="font-bold text-xs">Press Operator Shift Log & Color Notes:</label>
                <textarea
                  className="form-control mt-1"
                  rows="2"
                  value={operatorNotes}
                  onChange={(e) => setOperatorNotes(e.target.value)}
                ></textarea>
              </div>

              {/* Stage Handover Action */}
              <div className="mt-4 flex justify-between items-center">
                <button
                  className="btn btn-secondary"
                  onClick={() => setSelectedJobForModal(activeJob)}
                >
                  View Job Ticket Specs
                </button>
                <button
                  className="btn btn-success font-bold py-2 px-6 flex items-center gap-2"
                  onClick={handleCompletePressRun}
                >
                  <CheckCircle2 size={18} /> Complete Press Run & Hand Over to Finishing
                </button>
              </div>
            </div>
          </div>

          {/* Right: Daily Shift Log & Scrap History */}
          <div className="card w-1/3">
            <div className="card-header">
              <h3 className="card-title flex items-center gap-2">
                <Clock size={18} className="text-primary" /> Operator Shift Logs
              </h3>
            </div>

            <div className="workstation-logs-list">
              {workstationLogs.slice(0, 6).map(log => (
                <div key={log.id} className="log-card-item text-xs">
                  <div className="flex justify-between font-bold">
                    <span className="text-primary">{log.job_ticket_number}</span>
                    <span className="text-muted">{log.workstation_stage}</span>
                  </div>
                  <div className="text-muted mt-0.5">Operator: <strong>{log.operator_name}</strong></div>
                  <div className="flex justify-between mt-1 text-xxs">
                    <span>Good: <strong>{log.good_impressions?.toLocaleString()}</strong></span>
                    <span className="text-danger font-semibold">Scrap: {log.waste_sheets_logged}</span>
                  </div>
                  <p className="text-xxs text-muted mt-1 italic">{log.operator_notes}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="card p-8 text-center text-muted">
          No jobs currently waiting in the Press queue.
        </div>
      )}
    </div>
  </div>
);
};
