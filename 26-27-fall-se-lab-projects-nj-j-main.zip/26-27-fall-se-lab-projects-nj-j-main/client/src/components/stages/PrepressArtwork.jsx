import React, { useState } from 'react';
import {
  Palette,
  CheckCircle2,
  Clock,
  Search,
  FileText,
  Send,
  Eye,
  ShieldCheck,
  RotateCcw,
  Layers
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PrepressArtwork = () => {
  const {
    prepressJobs,
    updatePrepressJob,
    setActiveTab,
    activeSubTab,
    setActiveSubTab
  } = useApp();

  const currentSubTab = activeSubTab || 'all';
  const [filterType, setFilterType] = useState('All');

  const preflightCount = prepressJobs.filter(j => !j.production_release_authorized || j.revision_count > 1).length;
  const pendingProofsCount = prepressJobs.filter(p => !p.production_release_authorized).length;
  const ctpReadyCount = prepressJobs.filter(p => p.production_release_authorized).length;

  const filtered = prepressJobs.filter(j => {
    if (currentSubTab === 'preflight') {
      if (j.production_release_authorized && j.revision_count <= 1) return false;
    } else if (currentSubTab === 'proof_signoff') {
      if (j.production_release_authorized) return false;
    } else if (currentSubTab === 'ctp') {
      if (!j.production_release_authorized) return false;
    }
    return filterType === 'All' || j.artwork_type === filterType;
  });

  const subTabs = [
    {
      id: 'all',
      label: 'All Artwork Jobs',
      icon: Palette,
      badge: `${prepressJobs.length} Files`,
      badgeColor: 'bg-blue-100 text-blue-700'
    },
    {
      id: 'preflight',
      label: 'Artwork Pre-Flight',
      icon: Layers,
      badge: `${preflightCount} Review`,
      badgeColor: 'bg-purple-100 text-purple-700'
    },
    {
      id: 'proof_signoff',
      label: 'Proof Sign-Off',
      icon: Eye,
      badge: pendingProofsCount > 0 ? `${pendingProofsCount} Pending` : null,
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'ctp',
      label: 'CTP Output',
      icon: CheckCircle2,
      badge: `${ctpReadyCount} Plates Exposed`,
      badgeColor: 'bg-emerald-100 text-emerald-800'
    }
  ];

  return (
    <div className="space-y-3">
      {/* Consolidated Module Header with Sub-Tabs */}
      <div className="bg-white border-b border-slate-200 px-6 py-3 shadow-2xs select-none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 max-w-[1600px] mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#001523] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              03
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">Prepress Studio</h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200 font-bold">
                  Consolidated Suite
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Artwork pre-flight validation, customer proof sign-off, and CTP plate exposure release
              </p>
            </div>
          </div>

          {/* Sub-Tab Navigation Bar */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 gap-1 text-xs">
            {subTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = currentSubTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#001523] font-bold shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-purple-600' : 'text-slate-500'} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-bold ${tab.badgeColor}`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="p-4 max-w-[1600px] mx-auto space-y-4 text-xs select-none">

      {/* Gate 4 Banner */}
      <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between text-xs text-blue-900">
        <div className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-blue-600 shrink-0" />
          <span><b>[Gate 4 Enforced]:</b> Job card creation and press scheduling requires formal customer approval (date, mode, approved artwork version).</span>
        </div>
        <span className="font-mono text-[10px] text-blue-700 bg-blue-100 px-2 py-0.5 rounded font-bold">Gate 4 Active</span>
      </div>

      {/* Prepress Jobs List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        <div className="p-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50">
          <span className="font-bold text-xs text-slate-800 uppercase font-mono">Artwork Job Queues</span>
          <div className="flex flex-wrap items-center gap-1.5">
            {['All', 'Party File', 'Party File with Editing', 'New Design', 'Repeat Job with Editing'].map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-2.5 py-1 rounded text-[10px] font-semibold transition ${
                  filterType === t ? 'bg-[#002b41] text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-[10px] font-mono uppercase tracking-wider border-b border-slate-200">
                <th className="p-2.5">Job Ticket No</th>
                <th className="p-2.5">Customer Name</th>
                <th className="p-2.5">Artwork Source / Type</th>
                <th className="p-2.5">Designer</th>
                <th className="p-2.5 text-center">Version & Revisions</th>
                <th className="p-2.5">Proof Channel</th>
                <th className="p-2.5 text-center">Approval Status</th>
                <th className="p-2.5 text-center">CTP Release</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filtered.map(job => (
                <tr key={job.id} className="hover:bg-slate-50 transition">
                  <td className="p-2.5 font-mono font-bold text-slate-900">{job.job_ticket_number}</td>
                  <td className="p-2.5 font-semibold text-slate-800">{job.customer_name}</td>
                  <td className="p-2.5">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[10px] font-semibold">
                      {job.artwork_type}
                    </span>
                  </td>
                  <td className="p-2.5 text-slate-600 font-mono text-[11px]">{job.assigned_designer}</td>
                  <td className="p-2.5 text-center font-mono">
                    <span className="font-bold text-blue-700">{job.current_version}</span>
                    <span className="text-slate-400 text-[10px]"> ({job.revision_count} revs)</span>
                  </td>
                  <td className="p-2.5 text-[11px] text-slate-600">{job.proof_shared_channel}</td>
                  <td className="p-2.5 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                      job.customer_approval_status === 'Approved'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}>
                      {job.customer_approval_status}
                    </span>
                  </td>
                  <td className="p-2.5 text-center">
                    {job.production_release_authorized ? (
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold font-mono">
                        Authorized ({job.ctp_plates_generated} Plates)
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          updatePrepressJob(job.id, {
                            customer_approval_status: 'Approved',
                            production_release_authorized: true,
                            ctp_plates_generated: 4
                          });
                          alert(`Artwork ${job.job_ticket_number} approved! 4 CTP Plates queued.`);
                        }}
                        className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold transition shadow-xs"
                      >
                        Approve & Release
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
);
};
