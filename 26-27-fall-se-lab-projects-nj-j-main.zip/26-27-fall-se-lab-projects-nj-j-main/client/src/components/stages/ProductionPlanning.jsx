import React from 'react';
import {
  Kanban,
  Zap,
  Printer,
  Clock,
  ArrowRight,
  ArrowLeft,
  Eye,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Layers
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProductionPlanning = () => {
  const {
    jobOrders,
    advanceJobStage,
    bumpJobToTop,
    setSelectedJobForModal,
    setActiveTab,
    activeSubTab,
    setActiveSubTab
  } = useApp();

  const currentSubTab = activeSubTab || 'job_tickets';

  const stages = [
    { id: 'DesignProofing', label: '1. Design & Proofing', color: '#8b5cf6' },
    { id: 'PlateMaking', label: '2. CTP Plate Making', color: '#ec4899' },
    { id: 'PressRun', label: '3. Offset Press Run', color: '#f59e0b' },
    { id: 'FinishingQC', label: '4. Finishing & QC', color: '#10b981' },
    { id: 'DispatchReady', label: '5. Dispatch Ready', color: '#06b6d4' },
  ];

  const getNextStage = (current) => {
    switch (current) {
      case 'DesignProofing': return 'PlateMaking';
      case 'PlateMaking': return 'PressRun';
      case 'PressRun': return 'FinishingQC';
      case 'FinishingQC': return 'DispatchReady';
      case 'DispatchReady': return 'Delivered';
      default: return null;
    }
  };

  const getPrevStage = (current) => {
    switch (current) {
      case 'PlateMaking': return 'DesignProofing';
      case 'PressRun': return 'PlateMaking';
      case 'FinishingQC': return 'PressRun';
      case 'DispatchReady': return 'FinishingQC';
      default: return null;
    }
  };

  const urgentJobsCount = jobOrders.filter(
    j => (j.priority === 'Urgent' || j.is_rush_order) && j.current_stage !== 'Completed'
  ).length;

  const subTabs = [
    {
      id: 'job_tickets',
      label: 'Digital Job Tickets',
      icon: Kanban,
      badge: `${jobOrders.filter(j => j.current_stage !== 'Completed').length} Active`,
      badgeColor: 'bg-blue-100 text-blue-700'
    },
    {
      id: 'allocation',
      label: 'Machine Allocation',
      icon: Printer,
      badge: '3 Presses',
      badgeColor: 'bg-purple-100 text-purple-700'
    },
    {
      id: 'rush',
      label: 'Rush Fast-Track',
      icon: Zap,
      badge: urgentJobsCount > 0 ? `${urgentJobsCount} Rush` : null,
      badgeColor: 'bg-rose-100 text-rose-700'
    }
  ];

  return (
    <div className="space-y-3">
      {/* Consolidated Module Header with Sub-Tabs */}
      <div className="bg-white border-b border-slate-200 px-6 py-3 shadow-2xs select-none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 max-w-[1600px] mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#001523] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              04
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">Planning & Kanban</h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                  Consolidated Suite
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Visual Kanban workflow scheduling, offset machine allocation, and 1-click rush fast-tracking
              </p>
            </div>
          </div>

          {/* Sub-Tab Navigation Bar */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 gap-1 text-xs">
            {subTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = currentSubTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#001523] font-bold shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-blue-600' : 'text-slate-500'} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] font-bold ${tab.badgeColor}`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="stage-page-container">
        {/* Machine Allocation Summary if allocation tab active */}
        {currentSubTab === 'allocation' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-xs">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-xs text-slate-900">Ryobi 524HX (4-Color Offset)</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              </div>
              <p className="text-[11px] text-slate-500">Allocated: 2 Active Jobs (Brochures & Boxes)</p>
              <div className="mt-2 text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold inline-block">
                Running @ 11,000 IPH
              </div>
            </div>

            <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-xs">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-xs text-slate-900">Komori Lithrone 429</span>
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              </div>
              <p className="text-[11px] text-slate-500">Allocated: 1 Active Job (Pharma Inserts)</p>
              <div className="mt-2 text-[10px] font-mono text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-bold inline-block">
                Plate Mounting & Make-Ready
              </div>
            </div>

            <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-xs">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-xs text-slate-900">Konica Minolta AccurioPress</span>
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              </div>
              <p className="text-[11px] text-slate-500">Allocated: 3 Short-Run Digital Jobs</p>
              <div className="mt-2 text-[10px] font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-bold inline-block">
                Digital Variable Queue
              </div>
            </div>
          </div>
        )}

        {/* Kanban Board Multi-Column Layout */}
        <div className="kanban-board-container">
          {stages.map(stage => {
            const columnJobs = jobOrders
              .filter(j => {
                if (j.current_stage !== stage.id) return false;
                if (currentSubTab === 'rush') return j.priority === 'Urgent' || j.is_rush_order;
                return true;
              })
              .sort((a, b) => {
                if (a.is_rush_order && !b.is_rush_order) return -1;
                if (!a.is_rush_order && b.is_rush_order) return 1;
                return (a.queue_position || 99) - (b.queue_position || 99);
              });

          return (
            <div key={stage.id} className="kanban-column">
              <div className="kanban-column-header" style={{ borderTopColor: stage.color }}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm">{stage.label}</span>
                  <span className="column-count-badge">{columnJobs.length}</span>
                </div>
              </div>

              <div className="kanban-cards-wrapper">
                {columnJobs.length === 0 ? (
                  <div className="empty-kanban-slot">
                    <span>No jobs in this stage</span>
                  </div>
                ) : (
                  columnJobs.map((job, idx) => {
                    const isUrgent = job.priority === 'Urgent' || job.is_rush_order;
                    const nextStage = getNextStage(job.current_stage);
                    const prevStage = getPrevStage(job.current_stage);

                    return (
                      <div
                        key={job.id}
                        className={`kanban-job-card ${isUrgent ? 'urgent-glow-card' : ''}`}
                      >
                        {/* Top Tag Row */}
                        <div className="card-top-row">
                          <div className="flex items-center gap-1">
                            <span className="queue-rank-badge">#{job.queue_position || idx + 1}</span>
                            <span className="ticket-no font-bold">{job.job_ticket_number}</span>
                          </div>
                          {isUrgent ? (
                            <span className="badge badge-danger text-xxs font-bold flex items-center gap-0.5">
                              <Zap size={11} className="animate-pulse" /> [RUSH]
                            </span>
                          ) : (
                            <span className="badge badge-secondary text-xxs">{job.production_type}</span>
                          )}
                        </div>

                        {/* Title & Customer */}
                        <h4
                          className="job-card-title cursor-pointer hover:text-primary"
                          onClick={() => setSelectedJobForModal(job)}
                        >
                          {job.job_title}
                        </h4>
                        <div className="text-xs text-muted font-medium">{job.customer_name}</div>

                        {/* Technical Specs Snippet */}
                        <div className="job-specs-box">
                          <div className="spec-row">
                            <span>Quantity:</span>
                            <strong>{job.print_quantity?.toLocaleString()} pcs</strong>
                          </div>
                          <div className="spec-row">
                            <span>Machine:</span>
                            <strong className="text-primary">{job.assigned_press_machine?.split(' ')[0]} {job.assigned_press_machine?.split(' ')[1]}</strong>
                          </div>
                          <div className="spec-row">
                            <span>Deadline:</span>
                            <strong className={isUrgent ? 'text-danger flex items-center gap-0.5' : 'text-muted'}>
                              <Clock size={11} /> {new Date(job.target_completion_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </strong>
                          </div>
                        </div>

                        {/* Quick Action Footer */}
                        <div className="kanban-card-actions">
                          {/* Bump to Top Button for Urgent prioritization */}
                          <button
                            className={`btn btn-xxs ${isUrgent ? 'btn-warning' : 'btn-secondary'}`}
                            onClick={() => bumpJobToTop(job.id)}
                            title="Fast-track to position #1 in queue"
                          >
                            <Zap size={12} /> {isUrgent ? 'Top #1' : 'Prioritize'}
                          </button>

                          <button
                            className="btn btn-xxs btn-secondary"
                            onClick={() => setSelectedJobForModal(job)}
                            title="View official Job Card Ticket"
                          >
                            <Eye size={12} /> Card
                          </button>

                          {/* Stage Transition Arrows */}
                          <div className="flex gap-1 ml-auto">
                            {prevStage && (
                              <button
                                className="btn btn-xxs btn-secondary"
                                onClick={() => advanceJobStage(job.id, prevStage, 'Stage moved back')}
                                title={`Move back to ${prevStage}`}
                              >
                                <ArrowLeft size={12} />
                              </button>
                            )}
                            {nextStage && (
                              <button
                                className="btn btn-xxs btn-primary"
                                onClick={() => advanceJobStage(job.id, nextStage)}
                                title={`Advance to ${nextStage}`}
                              >
                                <ArrowRight size={12} />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </div>
);
};
